import scipy.io as scio
 
index=input("file_index=")
dataFile = 'data_'+index+'.mat'
data = scio.loadmat(dataFile)
print(data)
