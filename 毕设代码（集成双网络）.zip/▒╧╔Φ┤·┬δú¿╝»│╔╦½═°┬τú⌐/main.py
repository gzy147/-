import scipy.io as sio                     # import scipy.io for .mat file I/
import numpy as np                         # import numpy

# Implementated based on the PyTorch 
from memory import MemoryDNN
from optimization import bisection

import time

from concurrent.futures import ProcessPoolExecutor

def plot_rate(rate_his, rolling_intv=50):
    import matplotlib.pyplot as plt
    import pandas as pd
    import matplotlib as mpl

    rate_array = np.asarray(rate_his)
    df = pd.DataFrame(rate_his)
    y_major_locator=mpl.ticker.MultipleLocator(0.05)


    mpl.style.use('seaborn')
    fig, ax = plt.subplots(figsize=(15, 8))
    ax.yaxis.set_major_locator(y_major_locator)
#    rolling_intv = 20

    plt.plot(np.arange(len(rate_array))+1, np.hstack(df.rolling(rolling_intv, min_periods=1).mean().values), 'b')
    plt.fill_between(np.arange(len(rate_array))+1, np.hstack(df.rolling(rolling_intv, min_periods=1).min()[0].values), np.hstack(df.rolling(rolling_intv, min_periods=1).max()[0].values), color = 'b', alpha = 0.2)
    plt.ylabel('Normalized Computation Rate')
    plt.xlabel('Time Frames')
    plt.ylim(0.75, 1.05)
    plt.show()

def save_to_txt(rate_his, file_path):
    with open(file_path, 'w') as f:
        for rate in rate_his:
            f.write("%s \n" % rate)
            
def calculate_reward(m_list,r_list,h):
    for m in m_list:
        r_list.append(bisection(h/1000000, m)[0])
    return r_list

if __name__ == "__main__":
    '''
        This algorithm generates K modes from DNN, and chooses with largest
        reward. The mode with largest reward is stored in the memory, which is
        further used to train the DNN.
        Adaptive K is implemented. K = max(K, K_his[-memory_size])
    '''

    N = 10                       # number of users
    n = 10000                    # number of time frames
    K = N                        # initialize K = N
    decoder_mode = 'OP'          # the quantization mode could be 'OP' (Order-preserving) or 'KNN'
    Memory = 1024               # capacity of memory structure
    Delta = 16                   # Update interval for adaptive K

    print('#user = %d, #channel=%d, K=%d, decoder = %s, Memory = %d, Delta = %d'%(N,n,K,decoder_mode, Memory, Delta))
    # Load data
    channel = sio.loadmat('./data/data_%d' %N)['input_h']
    rate = sio.loadmat('./data/data_%d' %N)['output_obj'] # this rate is only used to plot figures; never used to train DROO.
    print(np.size(channel))

    # increase h to close to 1 for better training; it is a trick widely adopted in deep learning
    channel = channel * 1000000

    # generate the train and test data sample index
    # data are splitted as 80:20
    # training data are randomly sampled with duplication if n > total data size

    mem1 = MemoryDNN(net = [N, 100, 80, N],
                    learning_rate = 0.03,
                    training_interval=20,
                    batch_size=256,
                    memory_size=Memory
                    )
    mem2 = MemoryDNN(net = [N, 100, 80, N],
                    learning_rate = 0.03,
                    training_interval=20,
                    batch_size=256,
                    memory_size=Memory
                    )

    start_time = time.time()

    rate_his = []
    rate_his_ratio = []
    mode_his = []
    k_idx_his = []
    K_his = []
    executor=ProcessPoolExecutor()
    for i in range(n):#n为时间片个数
        if i % (n//10) == 0:#//为整数除法，向下取整
           print("%0.1f"%(i/n))
        '''if i> 0 and i % Delta == 0:
            # index counts from 0
            if Delta > 1:
                max_k = max(k_idx_his[-Delta:-1]) +1;
            else:
                max_k = k_idx_his[-1] +1;
            K = min(max_k +1, N)#总共更新10次K'''

        h = channel[i,:]

        # the action selection must be either 'OP' or 'KNN'
        m1=mem1.decode(h,K,decoder_mode)
        m2=mem2.decode(h,K,decoder_mode)
        #print("time consumed:%f"%(float(time2-time1)*10e5))
        m_list = m1+m2#测试。m_list为测试数据运行出的解集
        r_list = []
        r1=executor.submit(calculate_reward,m1,r_list,h)
        r2=executor.submit(calculate_reward,m2,r_list,h)#算出每个卸载决策对应的回报值'''s
        r_list=r1.result()+r2.result()
        # encode the mode with largest reward
        j=np.argmax(r_list)#K个卸载决策中，按此策略选择出回报值最大的一个的下标
        mem1.encode(h,m_list[j])
        mem2.encode(h,m_list[j])
        # the main code for DROO training ends here

        # the following codes store some interested metrics for illustrations
        # memorize the largest reward
        rate_his.append(np.max(r_list))
        rate_his_ratio.append(rate_his[-1] / rate[i][0])#测试所得回报值与数据集中回报值之比
        # record the index of largest reward
        k_idx_his.append(j%K)
        # record K in case of adaptive K
        K_his.append(K)
        mode_his.append(m_list[j])
        print("%d %d"%(i,K))

    total_time=time.time()-start_time
    #mem.plot_cost()
    plot_rate(rate_his_ratio)

    print("Averaged normalized computation rate:", sum(rate_his_ratio[-int(0.2*n): -1])/int(0.2*n))
    print('Total time consumed:%s'%total_time)
    print('Average time per channel:%s'%(total_time/n))

    # save data into txt
    save_to_txt(k_idx_his, "k_idx_his.txt")
    save_to_txt(K_his, "K_his.txt")
    #+save_to_txt(mem.cost_his, "cost_his.txt")
    save_to_txt(rate_his_ratio, "rate_his_ratio.txt")
    save_to_txt(mode_his, "mode_his.txt")
